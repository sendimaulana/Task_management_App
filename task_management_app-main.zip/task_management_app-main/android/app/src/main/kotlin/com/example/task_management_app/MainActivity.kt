package com.example.task_management_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
