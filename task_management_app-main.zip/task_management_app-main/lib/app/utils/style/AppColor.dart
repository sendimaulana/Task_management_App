import 'package:flutter/material.dart';

class AppColors {
  static const primaryBg = Color(0xFFA1CCF0);
  static const primaryText = Color.fromRGBO(90, 89, 89, 1);
  static const cardBg = Color(0xFFCBF6F3);
}